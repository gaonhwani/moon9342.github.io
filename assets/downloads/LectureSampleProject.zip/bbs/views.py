from django.shortcuts import render, redirect, get_object_or_404
from .models import Board, Comment
from .forms import BoardForm, BoardDetailForm
from users.forms import LoginForm
from django.http import JsonResponse
from users.models import Member


def b_list(request):

    if request.user.is_authenticated:
        posts = Board.objects.all().order_by('-id')
        return render(request, 'bbs/list.html', {
            'posts': posts
        })
    else:
        login_form = LoginForm()
        return render(request, 'users/login.html', {
            'login_form': login_form
        })


def b_create(request):
    # POST 방식
    if request.method == 'POST':
        # ModelForm을 사용하지 않으면
        # class의 instance를 만들어서 save() 호출
        # board = Board()
        # board.b_title = request.POST['b_title']
        # board.save()

        board_form = BoardForm(request.POST)

        if board_form.is_valid():
            new_post = board_form.save(commit=False)
            # 필요한 경우 field에 값을 수동으로 설정할 수 있다.
            # 예) new_post.b_like_count = 100
            new_post.save()
            return redirect('bbs:b_list')

    # GET 방식
    else:
        member = Member.objects.get(username=request.user.username)
        board_form = BoardForm(initial={'b_author': member})
        board_form.fields['b_author'].widget.attrs.update({
            'disabled': 'disabled'
        })
        # 로그인한 사람의 username으로 author부분을 설정한 후 수정할 수 없도록
        # disabled로 설정합니다.
        # 단, disabled로 설정된 field는 submit이 되지 않기 때문에 jQuery를 이용해
        # submit하기 전에 disabled를 해제하고 submit하는 방식으로 우회합니다.

    return render(request, 'bbs/create.html', {
        'board_form': board_form
    })


def b_detail(request, board_id):

    post = get_object_or_404(Board, id=board_id)

    is_author = False

    if str(post.b_author) == request.user.username:
        is_author = True
        member = Member.objects.get(username=request.user.username)
    else:
        member = Member.objects.get(username=post.b_author)

    board_detail_form = BoardDetailForm(instance=post,
                                        initial={'b_author': member})

    board_detail_form.show_board_detail()

    # comment 정보도 가져와야 한다.
    comments = post.comment_set.all().order_by('-id')

    return render(request, 'bbs/detail.html', {
        'board_detail_form': board_detail_form,
        'comments': comments,
        'is_author': is_author
    })


def b_delete(request):
    post = get_object_or_404(Board, id=request.GET['board_id'])
    post.delete()
    return redirect('bbs:b_list')


def b_like(request):
    post = get_object_or_404(Board, id=request.GET['board_id'])
    post.b_like_count += 1
    post.save()

    board_detail_form = BoardDetailForm(instance=post)
    board_detail_form.show_board_detail()
    return render(request, 'bbs/detail.html', {
        'board_detail_form': board_detail_form
    })


def b_update(request):
    post = get_object_or_404(Board, id=request.GET['board_id'])

    member = Member.objects.get(username=request.user.username)

    board_detail_form = BoardDetailForm(instance=post,
                                        initial={'b_author': member})
    board_detail_form.show_board_update()

    return render(request, 'bbs/update.html', {
        'board_detail_form': board_detail_form
    })


def b_update_process(request, board_id):
    post = get_object_or_404(Board, id=board_id)

    if request.method == 'POST':
        board_detail_form = BoardDetailForm(request.POST, instance=post)

        print(board_detail_form.is_valid())

        if board_detail_form.is_valid():

            board_detail_form.save()
            board_detail_form.show_board_detail()
            return render(request, 'bbs/detail.html', {
                'board_detail_form': board_detail_form,
                'is_author': True
            })


def c_delete(request):

    comment = get_object_or_404(Comment, id=request.GET['comment_id'])
    comment.delete()
    return JsonResponse({
        'code': '200'   # code 200의 의미는 삭제성공의 의미로 가정
    }, json_dumps_params={'ensure_ascii': True})


def c_create(request):

    comment = Comment()
    comment.c_author = request.GET['comment_author']
    comment.c_content = request.GET['comment_content']
    comment.board_id = request.GET['board_id']
    comment.save()
    return JsonResponse({
        'code': '200',   # code 200의 의미는 삭제성공의 의미로 가정
        'c_author': request.GET['comment_author'],
        'c_content': request.GET['comment_content'],
        'c_id': comment.id
    }, json_dumps_params={'ensure_ascii': True})
