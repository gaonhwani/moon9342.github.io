from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, \
    login as django_login, \
    logout as django_logout
from .forms import LoginForm, MemberForm
from django.http import HttpResponse
from .models import Member


def login(request):
    login_form = LoginForm()
    return render(request, 'users/login.html', {
        'login_form': login_form
    })


def logout(request):
    django_logout(request)
    return redirect('home')


def login_process(request):
    if request.method == 'POST':

        login_form = LoginForm(request.POST)

        username = login_form.data['username']
        password = login_form.data['password']

        # 가져온 username과 password에 해당하는 User가 있는지 판단
        # 존재할경우 user변수에는 User인스턴스가 할당되며,
        # 존재하지 않으면 None이 할당된다
        user = authenticate(username=username, password=password)

        if user is not None:
            django_login(request, user)
            return redirect('home')
        else:
            return HttpResponse('로그인 실패. 다시 시도 해보세요.')


def signup(request):
    member_form = MemberForm()
    return render(request, 'users/signup.html', {
        'member_form': member_form
    })


def signup_process(request):
    if request.method == "POST":
        member_form = MemberForm(request.POST)

        if member_form.is_valid():
            new_user = Member.objects.create_user(member_form.cleaned_data["username"],
                                                  email=member_form.cleaned_data['email'],
                                                  password=member_form.cleaned_data['password1'],
                                                  mobile=member_form.cleaned_data['mobile'])
            django_login(request, new_user)
            return redirect('home')
