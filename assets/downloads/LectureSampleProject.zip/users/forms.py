from django import forms
from .models import Member
from django.contrib.auth.forms import UserCreationForm


class MemberForm(UserCreationForm):

    class Meta:
        model = Member
        fields = ['username', 'email', 'mobile', 'password1', 'password2']


class LoginForm(forms.ModelForm):

    password = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(
            attrs={
                'class': 'form-control',
            }
        )
    )

    class Meta:
        model = Member
        fields = ['username', 'password']
