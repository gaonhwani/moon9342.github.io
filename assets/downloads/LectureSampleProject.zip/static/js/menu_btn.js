
$(function(event) {

    // 새글쓰기 버튼 클릭시
    $('#new_post_btn').on('click',function(event) {
        document.location.href = '/bbs/create/'
    })

    // 새글 등록 버튼 클릭시(실제 새글을 저장하기 위한 submit을 수행할 때)
    $('#post_create_btn').on('click',function(event) {
        $('#id_b_author').removeAttr('disabled')
        $('form').submit()
    })

    // 리스트버튼 클릭시
    $('#board_list_btn').on('click',function(event) {
        document.location.href='/bbs/list/'
    })

    // 수정버튼 클릭시
    $('#board_update_btn').on('click',function(event) {
        let query_string = '?board_id=' + $(this).attr('data-board_id')
        document.location.href='/bbs/update' + query_string
    })

    // 수정적용 버튼 클릭시(실제 수정된 글을 저장하기 위한 submit을 수행할 때)
    $('#post_update_btn').on('click',function(event) {
        $('#id_b_author').removeAttr('disabled')
        $('form').submit()
    })

    // 삭제버튼 클릭시
    $('#board_delete_btn').on('click',function(event) {
        let result = confirm('정말 삭제할까요?')
        if(result) {
            let query_string = '?board_id=' + $(this).attr('data-board_id')
            document.location.href='/bbs/delete' + query_string
        }
    })

    // 좋아요버튼 클릭시
    $('#board_like_btn').on('click',function(event) {
        let query_string = '?board_id=' + $(this).attr('data-board_id')
        document.location.href='/bbs/like' + query_string
    })

    // 댓글 등록버튼 클릭시
    $('#comment_create_btn').on('click',function(event) {

        $.ajax({
            async : true,
            url : '/bbs/commentCreate/',
            type : 'GET',
            data : {
                board_id : $('#board_id').text(),
                comment_author : $('#c_name').val(),
                comment_content : $('#c_content').val()
            },
            dataType : 'json',
            timeout : 3000,
            success : function(result) {
                let tr = $('<tr></tr>')
                let author_td = $('<td></td>').text(result.c_author)
                let content_td = $('<td></td>').text(result.c_content)
                let btn_td = $('<td></td>')
                let del_btn = $('<button></button>').attr('type','button')
                del_btn.attr('data-comment_id', result.c_id)
                del_btn.addClass('btn btn-danger')
                del_btn.attr('id','comment_delete_btn')
                del_btn.text('삭제')
                del_btn.on('click',function(event) {
                    $.ajax({
                        async : true,
                        url : '/bbs/commentDelete/',
                        type : 'GET',
                        data : {
                            comment_id : result.c_id
                        },
                        dataType : 'json',
                        timeout : 3000,
                        success : function(result) {
                            tr.remove()
                        },
                        error : function(err) {
                            alert('댓글 삭제 실패!')
                        }
                    })
                })

                btn_td.append(del_btn)

                tr.append(author_td)
                tr.append(content_td)
                tr.append(btn_td)

                $('#comment_body').append(tr)

            },
            error : function(err) {

                alert('댓글 등록 실패!')
            }
        })
    })

    // 댓글 삭제버튼 클릭시
    $('#comment_delete_btn').on('click',function(event) {
        let del_tr = $(this)
        $.ajax({
            async : true,
            url : '/bbs/commentDelete/',
            type : 'GET',
            data : {
                comment_id : $(this).attr('data-comment_id')
            },
            dataType : 'json',
            timeout : 3000,
            success : function(result) {
                del_tr.parent().parent().remove()
            },
            error : function(err) {
                alert('댓글 삭제 실패!')
            }
        })
    })

})